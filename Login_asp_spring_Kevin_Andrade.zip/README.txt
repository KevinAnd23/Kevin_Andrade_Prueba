User Management Patch (ASP.NET MVC + Spring API)
=================================================
Este paquete incluye:
- Controlador y vistas para Usuarios (listado y registro).
- Modelos (DTOs).
- Servicio HttpClient tipado para consumir tu API (usuarios y roles).
- appsettings.json con la sección Api.BaseUrl.
- Ejemplos de _Layout.cshtml y Program.cs para que puedas copiar/mergear.

Pasos rápidos:
1) Copia la carpeta 'Models', 'Services', 'Controllers', 'Views' a tu proyecto existente (respetando rutas).
2) Copia o mergea 'appsettings.json' (o añade la sección "Api": {"BaseUrl":"..."} a tu appsettings existente).
3) Abre Views/Shared/_Layout.cshtml y añade el item de menú 'Usuarios' si no lo tienes.
   (También se incluye un _Layout.cshtml de ejemplo en este paquete: Views/Shared/_Layout.cshtml.example)
4) Verifica Program.cs (o Startup.cs) para registrar el HttpClient tipado. 
   Se incluye un Program.cs.example con la configuración mínima (ajusta a tu proyecto).
5) Ejecuta la app. La nueva opción de menú llevará al listado de Usuarios, con un botón 'Nuevo Usuario' que abre el formulario.
   El formulario carga los roles desde GET /api/roles y crea el usuario con POST /api/users.

Ajustes de endpoints:
- GET /api/users  (listado de usuarios)
- GET /api/roles  (listado de roles)
- POST /api/users (crear usuario)

Si tus rutas/propiedades difieren, ajusta ApiClient.cs y los DTOs (Models/*).

¡Listo para entregar! Sube tu repo a GitHub y comparte solo el enlace.
