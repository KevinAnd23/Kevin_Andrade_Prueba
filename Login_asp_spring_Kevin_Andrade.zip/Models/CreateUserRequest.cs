using System.ComponentModel.DataAnnotations;

namespace Front_Login.Models
{
    public class CreateUserRequest
    {
        [Required, MinLength(3)]
        public string Username { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required, MinLength(3)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        public int RoleId { get; set; }

        [Required, MinLength(6)]
        public string Password { get; set; } = string.Empty;
    }
}
