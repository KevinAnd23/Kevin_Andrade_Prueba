namespace Front_Login.Models
{
    public class RoleDto
    {
        public int Id { get; set; }     // ajusta a tu API (long/Guid si aplica)
        public string Name { get; set; } = string.Empty;
    }
}
