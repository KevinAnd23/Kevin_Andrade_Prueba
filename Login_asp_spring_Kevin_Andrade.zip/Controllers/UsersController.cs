using Front_Login.Models;
using Front_Login.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Front_Login.Controllers
{
    public class UsersController : Controller
    {
        private readonly IApiClient _api;

        public UsersController(IApiClient api)
        {
            _api = api;
        }

        // GET: /Users
        public async Task<IActionResult> Index(CancellationToken ct)
        {
            try
            {
                var users = await _api.GetUsersAsync(ct);
                return View(users);
            }
            catch (Exception ex)
            {
                TempData["Error"] = "No se pudo cargar el listado de usuarios.";
                Console.WriteLine(ex);
                return View(new List<UserDto>());
            }
        }

        // GET: /Users/Create
        public async Task<IActionResult> Create(CancellationToken ct)
        {
            try
            {
                var roles = await _api.GetRolesAsync(ct);
                ViewBag.Roles = roles;
                return View(new CreateUserRequest());
            }
            catch (Exception ex)
            {
                TempData["Error"] = "No se pudieron cargar los roles.";
                Console.WriteLine(ex);
                ViewBag.Roles = new List<RoleDto>();
                return View(new CreateUserRequest());
            }
        }

        // POST: /Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateUserRequest model, CancellationToken ct)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Roles = await _api.GetRolesAsync(ct);
                return View(model);
            }

            var ok = await _api.CreateUserAsync(model, ct);
            if (!ok)
            {
                TempData["Error"] = "No se pudo registrar el usuario. Verifica los datos.";
                ViewBag.Roles = await _api.GetRolesAsync(ct);
                return View(model);
            }

            TempData["Success"] = "Usuario registrado correctamente.";
            return RedirectToAction(nameof(Index));
        }
    }
}
