using Front_Login.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Front_Login.Services
{
    public interface IApiClient
    {
        Task<List<UserDto>> GetUsersAsync(CancellationToken ct = default);
        Task<List<RoleDto>> GetRolesAsync(CancellationToken ct = default);
        Task<bool> CreateUserAsync(CreateUserRequest request, CancellationToken ct = default);
    }
}
