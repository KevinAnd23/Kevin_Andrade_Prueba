using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using Front_Login.Models;

namespace Front_Login.Services
{
    public class ApiClient : IApiClient
    {
        private readonly HttpClient _http;

        public ApiClient(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<UserDto>> GetUsersAsync(CancellationToken ct = default)
        {
            var resp = await _http.GetAsync("/api/users", ct);
            resp.EnsureSuccessStatusCode();
            var data = await resp.Content.ReadFromJsonAsync<List<UserDto>>(cancellationToken: ct);
            return data ?? new List<UserDto>();
        }

        public async Task<List<RoleDto>> GetRolesAsync(CancellationToken ct = default)
        {
            var resp = await _http.GetAsync("/api/roles", ct);
            resp.EnsureSuccessStatusCode();
            var data = await resp.Content.ReadFromJsonAsync<List<RoleDto>>(cancellationToken: ct);
            return data ?? new List<RoleDto>();
        }

        public async Task<bool> CreateUserAsync(CreateUserRequest request, CancellationToken ct = default)
        {
            var resp = await _http.PostAsJsonAsync("/api/users", request, ct);
            if (resp.IsSuccessStatusCode) return true;

            var error = await resp.Content.ReadAsStringAsync(ct);
            Console.WriteLine($"CreateUser error: {resp.StatusCode} - {error}");
            return false;
        }
    }
}
